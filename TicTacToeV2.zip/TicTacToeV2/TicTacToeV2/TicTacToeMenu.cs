﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeV2
{
    class TicTacToeMenu
    {
        private TicTacToe game;

        public void ShowGameModeMenu()
        {
			Console.Clear();
			Console.WriteLine("Choose game mode:");
            Console.WriteLine("1. Standard Mode");
            Console.WriteLine("2. Variation Mode");
			Console.WriteLine("0. Quit game");
		}

        public bool PlaceAPiece(string input)
        {
            return game.PlacePiece(input);
        }

        public bool ChooseGameMode(string choice)
        {
            if(choice == "1")
            {
                CreateStandardGame();
            }
            else if (choice == "2")
            {
                CreateVariationGame();
            }
            else
            {
                Console.WriteLine("Wrong input!");
                return false;
            }
            return true;
        }

        public string ChooseOption(string choice)
        {
            if (choice == "1")
            {
                return "1";
            }
            else if (choice == "2")
            {
                return "2";
            }
            else if (choice == "0")
            {
                return "0";
            }
            else
            {
                Console.WriteLine("Wrong input!");
                return "Error";
            }
        }

        public void ShowGameBoard()
        {
            Console.Clear();
            Console.WriteLine(game.GetGameBoardView());
        }

        private void CreateStandardGame()
        {
            game = new TicTacToe("Standard");
        }
        private void CreateVariationGame()
        {
            game = new TicTacToe("Variation");
        }

		public char GetPlayer()
		{
			return game.CurrentPlayer;
		}

		public int GetPlayerMoves()
		{
			return game.PlayerMoves;
		}

		public bool MovePiece(string input)
		{
			return game.MovePiece(input);
		}

		public bool PickAPiece(string input)
		{
			return game.PickAPiece(input);
		}

		public bool IsDraw()
		{
			return game.IsDraw();
		}
	}
}
