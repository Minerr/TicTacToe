﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeV2
{
    class Program
    {
		TicTacToeMenu menu = new TicTacToeMenu();

		static void Main(string[] args)
        {
            Program myProgram = new Program();
            myProgram.RunGameLoop();
        }

        private void RunGameLoop()
        {
            
            bool isGameRunning = true;
            do
            {
                // Choose game mode loop
                menu.ShowGameModeMenu();
                bool isValidInput = false;
				do
				{
					string userInput = Console.ReadLine();
					if (ShouldQuit(userInput))
					{
						return;
					}
					isValidInput = menu.ChooseGameMode(userInput);

				} while (isValidInput == false);


                // ----------------------------------

                // React to input
                bool shouldQuit = false;
                do
				{
					// Show gamemode
					menu.ShowGameBoard();
					
					if (menu.GetPlayerMoves() > 0)
					{
						Console.WriteLine("Write coordinate x,y or 0 to quit gamemode.");
						string userInput = Console.ReadLine();

						if (ShouldQuit(userInput))
						{
							shouldQuit = true;
						}
						else
						{
							shouldQuit = menu.PlaceAPiece(userInput);

							if (shouldQuit != true && menu.IsDraw())
							{
								shouldQuit = true;
								Console.WriteLine("Draw! Play again");
								PressKeyToContinue();
							}
							else
							{
								showWinner(shouldQuit);
							}

						}
					}
					else
					{
						Console.WriteLine("Pick piece x,y or 0 to quit gamemode");
						string userInput = Console.ReadLine();

						if (ShouldQuit(userInput))
						{
							shouldQuit = true;
						}
						else
						{
							bool isValid = menu.PickAPiece(userInput);
							if (isValid)
							{
								Console.WriteLine("Move piece to x,y");
								userInput = Console.ReadLine();
								shouldQuit = menu.MovePiece(userInput);
								showWinner(shouldQuit);
							}
						}
					}
						
                } while (shouldQuit != true);
            } while (isGameRunning);
        }

		private void showWinner(bool isWinner)
		{
			menu.ShowGameBoard();
			if (isWinner)
			{
				Console.WriteLine("Winner winner chicken dinner! Player " + menu.GetPlayer());
				PressKeyToContinue();
			}
		}

		private void PressKeyToContinue()
		{
			Console.WriteLine("Press any key to continue");
			Console.ReadKey();
		}

		private bool ShouldQuit(string input)
		{
			return (input == "0");
		}

    }
}